# Senai-Software

--> ///////////////////////////////


--> Software Agendamento Senai - DS 


--> Autor: Feito pela turma de Desenvolvimento de Sistemas - Manhã no polo SENAI CFP Fídelis Reis sob auxílio e orientação do instrutor Lenon Yuri Silva.


--> Data início: 12/05/2023 ; Previsão término: 25/05/2023.


--> Descrição: Projeto desenvolvido por múltiplos colabores do projeto da turma de DS do Senai. Segue a lista dos desenvolvedores do projeto:


// Lista dos nomes dos colaboradores (lembrem-se de colocar o nome completo de todos).


--> Versão: v1.0.0

--> ///////////////////////////////