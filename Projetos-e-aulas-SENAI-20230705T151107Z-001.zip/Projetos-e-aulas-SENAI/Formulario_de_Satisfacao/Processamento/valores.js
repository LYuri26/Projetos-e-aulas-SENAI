function setNumericValue(element, numericValue) {
  element.value = numericValue;
}
